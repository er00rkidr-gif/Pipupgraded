package com.piphorror.mod.ai;

import com.piphorror.mod.entity.PipEntity;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Comparator;
import java.util.List;
import java.util.Locale;

@Mod.EventBusSubscriber(modid = "piphorror", bus = Mod.EventBusSubscriber.Bus.FORGE)
public class PipChatListener {
    private static final String WAKE_WORD = "pip";
    private static final int LISTEN_TICKS = 120;
    private static final double SEARCH_RADIUS = 48.0D;

    @SubscribeEvent
    public static void onServerChat(ServerChatEvent event) {
        ServerPlayer player = event.getPlayer();
        if (player == null || !(player.level() instanceof ServerLevel level)) {
            return;
        }

        String rawMessage = event.getRawText().trim();
        String lower = rawMessage.toLowerCase(Locale.ROOT);
        PipEntity nearestPip = findNearestPip(level, player);
        if (nearestPip == null) {
            return;
        }

        boolean mentionsPip = lower.contains(WAKE_WORD);
        boolean alreadyListening = nearestPip.isListening();

        if (!mentionsPip && !alreadyListening) {
            return;
        }

        if (mentionsPip) {
            boolean didListen = nearestPip.startLookoutListen(player, LISTEN_TICKS);
            if (!didListen) {
                // Fake/Scary Pip refused to raise its paw and ignored the wake word
                player.displayClientMessage(Component.literal("§4...it didn't raise its paw."), true);
                return;
            }

            String inlineCommand = extractEventFromText(lower);
            if (inlineCommand != null) {
                level.getServer().execute(() -> {
                    PipEventDirector.executeEvent(level, player, nearestPip, inlineCommand);
                });
            } else {
                player.displayClientMessage(Component.literal("§8[Pip] §7*raises front paw to ear, listening...*"), true);
            }
            return;
        }

        // Player spoke a follow-up instruction while Real Pip was listening
        String followUpEvent = extractEventFromText(lower);
        if (followUpEvent != null) {
            level.getServer().execute(() -> {
                PipEventDirector.executeEvent(level, player, nearestPip, followUpEvent);
            });
        }
    }

    private static PipEntity findNearestPip(ServerLevel level, ServerPlayer player) {
        AABB box = player.getBoundingBox().inflate(SEARCH_RADIUS);
        List<PipEntity> list = level.getEntitiesOfClass(PipEntity.class, box);
        return list.stream()
            .min(Comparator.comparingDouble(p -> p.distanceToSqr(player)))
            .orElse(null);
    }

    private static String extractEventFromText(String lower) {
        if (lower.contains("lights") || lower.contains("dark") || lower.contains("torch") || lower.contains("flicker") || lower.contains("blackout")) {
            return "lights_flicker";
        }
        if (lower.contains("behind") || lower.contains("stalk") || lower.contains("follow") || lower.contains("watch") || lower.contains("sneak")) {
            return "stalk_behind";
        }
        if (lower.contains("knock") || lower.contains("door") || lower.contains("open") || lower.contains("let me in") || lower.contains("house")) {
            return "door_knock";
        }
        if (lower.contains("whisper") || lower.contains("talk") || lower.contains("speak") || lower.contains("mimic") || lower.contains("voice") || lower.contains("hello")) {
            return "mimic_whisper";
        }
        if (lower.contains("hunt") || lower.contains("chase") || lower.contains("attack") || lower.contains("kill") || lower.contains("run")) {
            return "hunt_escalation";
        }
        if (lower.contains("peek") || lower.contains("hallucination") || lower.contains("corner") || lower.contains("stare") || lower.contains("look")) {
            return "hallucination_decoy";
        }
        return null;
    }
}
