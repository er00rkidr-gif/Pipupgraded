package com.piphorror.mod.ai;

import com.piphorror.mod.entity.PipEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

public class PipEventDirector {
    public static boolean executeEvent(ServerLevel level, ServerPlayer target, PipEntity pip, String eventKey) {
        if (level == null || target == null || pip == null) {
            return false;
        }

        switch (eventKey) {
            case "lights_flicker" -> {
                pip.triggerTimedState(PipEntity.STATE_SUMMON, 100);
                extinguishNearbyLights(level, target.blockPosition(), 12);
                target.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 90, 0, false, false));
                level.playSound(null, target.blockPosition(), SoundEvents.CANDLE_EXTINGUISH, SoundSource.HOSTILE, 1.2F, 0.55F);
            }
            case "stalk_behind" -> {
                pip.triggerTimedState(PipEntity.STATE_PROWL_WALK, 140);
                teleportBehindPlayer(level, target, pip, 4.8D);
                level.playSound(null, pip.blockPosition(), SoundEvents.CAT_PURR, SoundSource.HOSTILE, 0.9F, 0.5F);
            }
            case "door_knock" -> {
                pip.triggerTimedState(PipEntity.STATE_PEEK, 80);
                triggerNearestDoorKnock(level, target.blockPosition(), 14);
            }
            case "mimic_whisper" -> {
                pip.triggerTimedState(PipEntity.STATE_LOOKOUT_LISTEN, 90);
                level.playSound(null, target.blockPosition(), SoundEvents.AMBIENT_CAVE.value(), SoundSource.HOSTILE, 1.0F, 0.65F);
                target.displayClientMessage(Component.literal("§4Pip heard you..."), true);
            }
            case "hunt_escalation" -> {
                pip.triggerTimedState(PipEntity.STATE_HUNT, 200);
                pip.getNavigation().moveTo(target, 1.45D);
                target.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 120, 0, false, false));
                level.playSound(null, pip.blockPosition(), SoundEvents.CAT_HISS, SoundSource.HOSTILE, 1.3F, 0.45F);
            }
            case "hallucination_decoy" -> {
                pip.triggerTimedState(PipEntity.STATE_PEEK, 120);
                Vec3 look = target.getLookAngle().normalize();
                Vec3 cornerPos = target.position().add(look.scale(7.5D));
                level.sendParticles(ParticleTypes.SOUL, cornerPos.x, cornerPos.y + 1.1D, cornerPos.z, 24, 0.4D, 0.5D, 0.4D, 0.02D);
                level.playSound(null, BlockPos.containing(cornerPos), SoundEvents.ENDERMAN_STARE, SoundSource.HOSTILE, 0.85F, 0.6F);
            }

            default -> {
                return false;
            }
        }
        return true;
    }

    private static void extinguishNearbyLights(ServerLevel level, BlockPos center, int radius) {
        BlockPos.betweenClosedStream(center.offset(-radius, -4, -radius), center.offset(radius, 5, radius))
            .forEach(pos -> {
                BlockState state = level.getBlockState(pos);
                if (state.is(Blocks.TORCH) || state.is(Blocks.WALL_TORCH) || state.is(Blocks.LANTERN)) {
                    level.destroyBlock(pos, true);
                }
            });
    }

    private static void teleportBehindPlayer(ServerLevel level, ServerPlayer player, PipEntity pip, double distance) {
        Vec3 forward = player.getLookAngle();
        Vec3 flatForward = new Vec3(forward.x, 0, forward.z).normalize();
        Vec3 behind = player.position().subtract(flatForward.scale(distance));
        pip.teleportTo(behind.x, player.getY(), behind.z);
        pip.getLookControl().setLookAt(player, 90.0F, 90.0F);
    }

    private static void triggerNearestDoorKnock(ServerLevel level, BlockPos center, int radius) {
        BlockPos.betweenClosedStream(center.offset(-radius, -3, -radius), center.offset(radius, 4, radius))
            .filter(pos -> level.getBlockState(pos).getBlock() instanceof DoorBlock)
            .findFirst()
            .ifPresent(doorPos -> {
                level.playSound(null, doorPos, SoundEvents.ZOMBIE_ATTACK_WOODEN_DOOR, SoundSource.BLOCKS, 1.1F, 0.75F);
                BlockState state = level.getBlockState(doorPos);
                if (state.getBlock() instanceof DoorBlock door) {
                    door.setOpen(null, level, state, doorPos, !state.getValue(DoorBlock.OPEN));
                }
            });
    }
}
