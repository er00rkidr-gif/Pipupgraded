# Pip AI Horror — Forge 1.20.1 Upgrade Guide

## What Was Added / Upgraded
1. **4-Legged Quadruped Cat Models (`geo/pip.geo.json` & `geo/pip_fake.geo.json`)**
   - Full quadruped feline skeleton (`pelvis -> spine_chest -> neck -> head`, 4 articulated limbs with shins & paws, cheek tufts, muzzle, hinged jaw, glowing eyes, and 4-segment tail).
   - `pip_fake.geo.json` adds gaunt elongated legs, torn left ear, and fanged jaw for the Fake/Scary Pip mimic variant.
2. **Real Pip vs Fake/Scary Pip Listening Mechanics**
   - **Real Pip**: When a player says "pip" in chat within 48 blocks, Real Pip drops into a 4-legged attentive stance, raises its front-right paw beside its twitching right ear (`animation.pip.lookout_listen`), and executes follow-up horror commands.
   - **Fake/Scary Pip**: Ignores "pip", refuses to raise its paw, snaps its head sideways and unhinges its jaw (`animation.pip.fake_ignore_stare`), giving players an atmospheric tell.
3. **Brigadier Commands (`src/main/java/com/piphorror/mod/command/PipEventsCommand.java`)**
   - `/pip listen [player]`
   - `/pip variant <real|fake>`
   - `/pip event <lights_flicker|stalk_behind|door_knock|mimic_whisper|hunt_escalation|hallucination_decoy> [player]`
   - `/pip state <idle_stalk|lookout_listen|prowl_walk|peek_corner|crawl_hunt|fake_ignore_stare|event_summon>`

## Quick Build Verification
1. Copy the contents of this archive over your Forge 1.20.1 MDK workspace.
2. Confirm GeckoLib 4 (`software.bernie.geckolib:geckolib-forge-1.20.1:4.4.9`) is in `build.gradle`.
3. Register `PipEntity.createAttributes()` in your `EntityAttributeCreationEvent` subscriber and `PipModel` in your `GeoEntityRenderer`.
4. Run `./gradlew build`.
